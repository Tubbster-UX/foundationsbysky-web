$(document).ready((function(){$("#navIcon").click((function(){$("#navContent").toggleClass("block").toggleClass("hidden")}))}));
//# sourceMappingURL=index.8ee9107a.js.map
